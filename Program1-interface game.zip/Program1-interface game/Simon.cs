﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program1_interface_game
{
    public partial class Simon : Form
    {
        Player player;
        public Simon(Player player)
        {
            InitializeComponent();
            this.player = player;
            

            welcomeLabel.Text = $"Welcome: {player.Last}";
            currentLevelLabel.Text = $"Current Player level: {player.Level}";
        }
    }

    
}
